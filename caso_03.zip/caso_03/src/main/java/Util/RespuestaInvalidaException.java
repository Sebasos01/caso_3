package Util;

public class RespuestaInvalidaException extends Exception {
    public RespuestaInvalidaException(String mensaje) {
        super(mensaje);
    }
}