1. El zip contiene la carpeta doc, aquí se encuentra el informe y este archivo, contiene la carpeta src con el código fuente
   y los dos archivos conteniendo la llave pública y privada del servidor.
2. Para correr simplemente copie y pegue las llaves y la carpeta src en el directorio de un proyecto de intellj idea
   recien creado. En el parquete Servidor, se encuentra la clase ServidorMain, este es el primer proceso que se tiene que correr,
   esto pondrá al servidor a escuchar en el puerto 4030. Luego, en el paquete Cliente, puede poner a correr el proceso ClienteMain,
   el cual simula varios clientes concurrentes enviando peticiones al servidor.    
3. IMPORTANTE -> este caso fue hecho en Java 17. 